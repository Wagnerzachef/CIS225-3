import java.awt.*;
import java.awt.geom.*;
import java.util.Random;
/**
 * Write a description of class BoxBall here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class BoxBall
{
    // instance variables - replace the example below with your own
    private static final int GRAVITY = 3; // effect of gravity

    private int ballDegradation = 2;
    private Ellipse2D.Double circle;
    private Color color;
    private int diameter;  
    private int xPosition;
    private int yPosition;
    private final int groundPosition;      // y position of ground
    private final int leftWallPos;         // x position of left wall
    private final int rightWallPos;        // x position of right wall
    private boolean isMovingRight;         // check if it is moving right
    private Random rng;
    private Canvas canvas;
    private int ySpeed = 1;

    /**
     * Constructor for objects of class BoxBall
     */
    public BoxBall(int xPos, int yPos, int ballDiameter, Color ballColor, int groundPos, int leftWall, int rightWall, Canvas drawingCanvas)
    {
        // initialise instance variables
        rng = new Random();
        xPosition = xPos;
        yPosition = yPos;
        color = new Color(rng.nextInt(256), rng.nextInt(256), rng.nextInt(256));
        diameter = ballDiameter;
        groundPosition = groundPos;
        leftWallPos = leftWall; 
        rightWallPos = rightWall;
        canvas = drawingCanvas; 
        
        isMovingRight = rng.nextBoolean();
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void draw() {
        canvas.setForegroundColor(color);
        canvas.fillCircle(xPosition, yPosition, diameter);
    }
    public void erase() {
        canvas.eraseCircle(xPosition, yPosition, diameter);
    }
    public void move()
    {
        // remove from canvas at the current position
        erase();
            
        // compute new position
        ySpeed += GRAVITY;
        yPosition += ySpeed;
        if(isMovingRight) {
            xPosition += 2;
        }
        else {
            xPosition -=2;
        }
        if(xPosition >= (rightWallPos - diameter)){
            isMovingRight = false;
            xPosition = rightWallPos - diameter;
        }
        if(xPosition <= leftWallPos){
            isMovingRight = true;
            xPosition = leftWallPos;
        }

        // check if it has hit the ground
        if (yPosition >= (groundPosition - diameter) && ySpeed > 0) {
            yPosition = (int)(groundPosition - diameter);
            ySpeed = -ySpeed + ballDegradation; 
        }

        // draw again at new position
        draw();
    }    
    public int getyPosition() 
    { 
        return yPosition; 
    }
    public int getDiameter() 
    { 
        return diameter; 
    }
}

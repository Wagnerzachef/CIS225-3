import java.awt.Color;
import java.util.HashSet;
import java.util.Random;
/**
 * Class BallDemo - a short demonstration showing animation with the 
 * Canvas class. 
 *
 * @author Michael Kölling and David J. Barnes
 * @version 2016.02.29
 */

public class BallDemo   
{
    private Canvas myCanvas;
    private Random rng;

    /**
     * Create a BallDemo object. Creates a fresh canvas and makes it visible.
     */
    public BallDemo()
    {
        myCanvas = new Canvas("Ball Demo", 600, 500);
        rng = new Random();
    }

    /**
     * Simulate two bouncing balls
     * 
     * @param amount number of balls
     */
    public void bounce(int amount)
    {
        int ground = 400;   // position of the ground line
        

        myCanvas.setVisible(true);

        // draw the ground
        myCanvas.setForegroundColor(Color.BLACK);
        myCanvas.drawLine(50, ground, 550, ground);
        
        // create and show the balls
        HashSet<BouncingBall> balls = new HashSet<>(amount);
        for(int i = 0; i < amount; i++) {
            balls.add(new BouncingBall(50 + rng.nextInt(250), 50 + (i*15), 16 + (i*4), Color.RED, ground, myCanvas));
        }
        balls.forEach(BouncingBall::draw);
        // make them bounce
        boolean finished =  false;
        while (!finished) {
            myCanvas.wait(50);           // small delay
            for(BouncingBall ball : balls) {
                ball.move();
                if(ball.getXPosition() >= 550) {
                finished = true;
                }
            }
            // stop once ball has travelled a certain distance on x axis
            
        }
    }
    public void boxBounce(int amount)
    {
        myCanvas.setVisible(true);
        myCanvas.setForegroundColor(Color.BLACK);
        myCanvas.fillRectangle(20, 20, 500, 400);
        myCanvas.setForegroundColor(Color.WHITE);
        myCanvas.fillRectangle(25, 25, 490, 390);
        int ground = 25 + 400;
        int leftWall = 25;
        int rightWall = 25 + 500;
        
        HashSet<BoxBall> balls = new HashSet<>(amount); 
        for (int i = 0; i < amount; i++) {
        balls.add(new BoxBall(50 + rng.nextInt(250), 10 + rng.nextInt(80),
                16 + (i*4), Color.BLUE, ground, leftWall, rightWall, myCanvas));
        }
        balls.forEach(BoxBall::draw);
        boolean finished =  false;
        while (!finished) {
            myCanvas.wait(50);        
            finished = true;
            for(BoxBall ball : balls) {
                ball.move();
                if (ball.getyPosition() < (ground - ball.getDiameter())) {
                    finished = false;
                }
            }
        }
    }
}

import java.util.ArrayList;
import java.util.Scanner;
/**
 * A class that stores and manipulates the die.
 *
 * @author Zachary Wagner
 * @version 1
 */
public class Controller
{
    private int targetNumber;
    private ArrayList<Die> dice;
    private int dieType;
    private int dieCount;
    
    /**
     * Constructor for objects of class Controller
     */
    public Controller()
    {
        dice = new ArrayList<Die>();
    }

    /**
     * A method to add dice using user input in the terminal.
     * 
     */
    public void pickDice()
    {
        boolean validType = false;
        Scanner input = new Scanner(System.in);
        
        while(!validType) {
            System.out.println("Please select a valid die type. Valid die types are: 4, 6, 8, 10, 12, 20, and 100.");
            dieType = input.nextInt();
            if(dieType == 4 || dieType == 6 || dieType == 8 || dieType == 10 || dieType == 12 || dieType == 20 || dieType == 100) {
                validType = true;
            }
        }
        while(dieCount < 1 || dieCount > 10) {
            System.out.println("The die count has a max of 10.");
            dieCount = input.nextInt();
        }
        for(int i = 0; i < dieCount; i++) {
            if(dice.size() <=10) {
                addDie(dieType);
            }
        }
    }
    
    /**
     * 
     */
    public ArrayList<Integer> rollDice()
    {
        ArrayList<Integer> rolls = new ArrayList<Integer>();
        for(Die die : dice) {
            int roll = die.rollDie();
            if(roll == die.getDieType()) {
                int total = roll;
                while(roll == die.getDieType()) {
                    roll = die.rollDie();
                    total += roll;
                }
                rolls.add(total);
            }
            else {
                rolls.add(roll);
            }
        }
        return rolls;
    }
    
    /**
     * set the target number.
     */
    public void setTarget()
    {
        Scanner target = new Scanner(System.in);
        while(targetNumber < 5 || targetNumber > 30) {
            System.out.println("Please anter a target number between 5 and 30.");
            targetNumber = target.nextInt();
        }
    }
    
    /**
     * Check for target number.
     */
    public boolean checkForTarget(ArrayList<Integer> rolls)
    {
        int total = 0;
        for(Integer roll : rolls) {
            total += roll;
        }
        if(total >= targetNumber) {
            return true;
        }
        else {
            return false;
        }
    }
    
    /**
     * Checks for busts.
     */
    public boolean bust(ArrayList<Integer> rolls)
    {
        int onesCount = 0;
        for(Integer roll : rolls) {
            if(roll == 1) {
                onesCount++;
            }
        }
        if(onesCount > rolls.size()/2) {
            return true;
        }
        else {
            return false;
        }
    }
    
    /**
     * a method to print out the rolls.
     */
    public void printRolls(ArrayList<Integer> rolls)
    {
        int total = 0;
        
        System.out.println("Your rolls are: ");
        for(int i = 0; i < rolls.size(); i++)
        {
            System.out.println(rolls.get(i));
            total += rolls.get(i);
        }
        System.out.print("Your total roll is: " + total + " ");
    }
    
    /**
     * a method to add a single die.
     */
    private void addDie(int dieType)
    {
        dice.add(new Die(dieType));
    }
}

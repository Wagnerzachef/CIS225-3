import java.util.Random;
/**
 * A class to store the information about a single die.
 *
 * @author Zachary Wagner
 * @version 1
 */
public class Die
{
    // instance variables - replace the example below with your own
    private int dieType;

    /**
     * Constructor for objects of class Die
     */
    public Die(int dieType)
    {
        this.dieType = dieType;
    }

    /**
     * A method to roll the die.
     *
     * @return    what the die rolled
     */
    public int rollDie()
    {
        Random rng = new Random();
        int rolled = rng.nextInt(dieType) + 1;
        return rolled;
    }
    
    /**
     * A method to set the die type after construction.
     * 
     * @param dieType The type of die you want to roll.
     */
    public void setDieType(int dieType)
    {
        this.dieType = dieType;
    }
    
    /**
     * A method to get the die type.
     * 
     * @return returns the die type.
     */
    public int getDieType()
    {
        return dieType;
    }
}

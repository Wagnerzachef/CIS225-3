import java.util.ArrayList;
import java.util.Scanner;
/**
 * Handles the game
 *
 * @author Zachary Wagner
 * @version 1
 */
public class Manager
{

    /**
     * Run the game.
     */
    public void gameStart()
    {
        boolean gameOver = false;
        while(!gameOver) {
            ArrayList<Integer> rolls = new ArrayList<Integer>();
            Controller dice = new Controller();
            
            dice.pickDice();
            dice.setTarget();
            rolls = dice.rollDice();
            dice.printRolls(rolls);
            if(dice.bust(rolls)) {
                System.out.println("Bust!");
            }
            else {
                if(dice.checkForTarget(rolls)) {
                    System.out.println("Target was hit.");
                }
                else {
                    System.out.println("Target was missed.");
                }
            }
            gameOver = true;
        }
    }
}


/**
 * Write a description of class NameGenerator here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class NameGenerator
{
    public NameGenerator()
    {
        
    }   
    public static String generateStarWarsName(String firstName, String lastName, String mothersMaidenName, String hometown)
    {
        String swFirstName = lastName.substring(0, 3) + firstName.substring(0, 2);
        String swLastName = mothersMaidenName.substring(0, 2) + hometown.substring(0, 3);
        return swFirstName + " " + swLastName;    
    }
}
    



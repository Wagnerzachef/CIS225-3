import java.util.Random;
import java.util.ArrayList;
/**
 * Write a description of class RandomTester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class RandomTester
{
    // instance variables - replace the example below with your own
    private int x;
    private int number;
    private ArrayList<String> response;
    private Random rug;

    /**
     * Constructor for objects of class RandomTester
     */
    public RandomTester()
    {
        // initialise instance variables
        x = 0;
        response = new ArrayList<>();
        rug = new Random();
        
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void printOneRandom()
    {
        Random pine = new Random();
        int help = pine.nextInt();
        System.out.println(help);
    }
    public void printMultiRandom(int howMany)
    {
        number = howMany;
        x = 0;
        while(x < number) {
            Random pine = new Random();
            int help = pine.nextInt();
            System.out.println(help);
            x++;
        }
    }
    public void throwDie()
    {
        Random pine = new Random();
        int help = pine.nextInt(6) + 1;
        System.out.println(help);
    }
    public String getResponse()
    {
        response.add("no");
        response.add("yes");
        response.add("maybe");
        int help = rug.nextInt(response.size());
        return response.get(help);
        
    }
    public void getMax(int max)
    {
        Random pine = new Random();
        int help = pine.nextInt(max) + 1;
        System.out.println(help);
    }
    public void getMinMax(int min, int max)
    {
        Random pine = new Random();
        int help = pine.nextInt(max - min) + min;
        System.out.println(help);
    }
}

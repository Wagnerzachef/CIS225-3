import java.util.HashMap;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.Arrays;
/**
 * Write a description of class SortingTest here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SortingTest
{
    // instance variables - replace the example below with your own
    

    /**
     * Constructor for objects of class SortingTest
     */
    public SortingTest()
    {
        // initialise instance variables
        
    }

    
    public static int[] sortArray(int[] sortMe)
    {
       Arrays.sort(sortMe);
       return sortMe;
    }
}

public enum Cell
{
    X, O, EMPTY;
}

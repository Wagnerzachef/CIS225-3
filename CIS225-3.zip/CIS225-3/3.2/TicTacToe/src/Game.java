
/**
 * The class that controls the game
 */
public class Game {
    private int currentPlayer;
    private int winningPlayer;
    public Game()
    {
        currentPlayer = 1;
        winningPlayer = 0;
    }

    /**
     * The method that plays the game
     */
    public void game()
    {
        boolean gameOver = false;
        Manager manage = new Manager();
        currentPlayer = 1;
        winningPlayer = 0;
        while(!gameOver) {
            manage.move(currentPlayer);
            manage.printBoard();
            winningPlayer = manage.winCheck();
            if(winningPlayer != 0) {
                printWinner();
                gameOver = true;
            }
            swapPlayer();
        }
        manage.clearBoard();
        System.out.println("Have A Good Day.");
    }

    /**
     * a method to swap players
     */
    public void swapPlayer()
    {
        if(currentPlayer == 1) {
            currentPlayer = 2;
        }
        else if(currentPlayer == 2) {
            currentPlayer = 1;
        }
    }
    public void printWinner()
    {
        switch (winningPlayer)
        {
            case 1:
                System.out.println("Player 1 won the game.");
                break;
            case 2:
                System.out.println("Player 2 won the game.");
                break;
            case 3:
                System.out.println("A cat laid down on the board. No one won.");
                break;
        }
    }

    public static void main(String[] args) {
        Game thing = new Game();
        thing.game();
    }
}

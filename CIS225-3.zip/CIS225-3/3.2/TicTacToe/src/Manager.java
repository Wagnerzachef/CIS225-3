import java.util.Scanner;
/**
 * A class to make the board, make the moves, and reset the board.
 */
public class Manager
{
    private Cell[][] board;
    public Manager() {
        board = new Cell[3][3];
        for(int i=0; i < 3; i++) {
            for(int j = 0; j < 3; j++) {
                board[i][j] = Cell.EMPTY;
            }
        }
    }

    /**
     * A method to print the board out.
     */
    public void printBoard()
    {
        for(int i = 0; i < 3; i++) {
            System.out.print("\n");
            for(int j = 0; j < 3; j++) {
                System.out.print("|");
                if(board[i][j] == Cell.EMPTY) {
                    System.out.print(" ");
                }
                else if(board[i][j] == Cell.X) {
                    System.out.print("X");
                }
                else if(board[i][j] == Cell.O) {
                    System.out.print("O");
                }
                if(j == 2) {
                    System.out.print("|");
                }
            }
        }
        System.out.print("\n");
    }
    /**
     * a method to make a move on the board.
     *
     * @param currentPlayer The current player of two player tic tac toe
     */
    public void move(int currentPlayer)
    {
        int cell = 0;
        boolean valid = false;
        Cell cellType = Cell.EMPTY;
        Scanner scan = new Scanner(System.in);

        if(currentPlayer == 1) {
            cellType = Cell.X;
        }
        else if(currentPlayer == 2) {
            cellType = Cell.O;
        }

        while(!valid) {
            while(cell < 1 || cell > 9) {
                System.out.println("Player " + currentPlayer + ": it is your turn.");

                cell = scan.nextInt();

                if(cell < 1 || cell > 9) {
                    System.out.println("That move is invalid. Remember, the board only has 9 cells.");
                }
            }
            switch(cell)
            {
                case 1:
                    if(board[0][0] == Cell.EMPTY) {
                        board[0][0] = cellType;
                        valid = true;
                    }
                break;
                case 2:
                    if(board[0][1] == Cell.EMPTY) {
                        board[0][1] = cellType;
                        valid = true;
                    }
                break;
                case 3:
                    if(board[0][2] == Cell.EMPTY) {
                        board[0][2] = cellType;
                        valid = true;
                    }
                break;
                case 4:
                    if(board[1][0] == Cell.EMPTY) {
                        board[1][0] = cellType;
                        valid = true;
                    }
                break;
                case 5:
                    if(board[1][1] == Cell.EMPTY) {
                        board[1][1] = cellType;
                        valid = true;
                    }
                break;
                case 6:
                    if(board[1][2] == Cell.EMPTY) {
                        board[1][2] = cellType;
                        valid = true;
                    }
                break;
                case 7:
                    if(board[2][0] == Cell.EMPTY) {
                        board[2][0] = cellType;
                        valid = true;
                    }
                break;
                case 8:
                    if(board[2][1] == Cell.EMPTY) {
                        board[2][1] = cellType;
                        valid = true;
                    }
                break;
                case 9:
                    if(board[2][2] == Cell.EMPTY) {
                        board[2][2] = cellType;
                        valid = true;
                    }
                break;
            }
            if(valid == false) {
                System.out.println("That move is not valid.");
                cell = 0;
            }
        }
    }
    /**
     * a method to check for a winner.
     */
    public int winCheck()
    {
        int winner = 0;
        boolean checkEmpty = false;
        for(int i = 0; i < 3; i++) {
            if(board[i][0] == board[i][1] && board[i][0] == board[i][2]) {
                if(board[i][0] == Cell.X) {
                    winner = 1;
                    break;
                }
                else if(board[i][0] == Cell.O) {
                    winner = 2;
                    break;
                }
            }
            else if(board[0][i] == board[1][i] && board[0][i] == board[2][i]) {
                if(board[0][i] == Cell.X) {
                    winner = 1;
                    break;
                }
                else if(board[0][i] == Cell.O) {
                    winner = 2;
                    break;
                }
            }
        }
        if(board[0][0] == board[1][1] && board[0][0] == board[2][2]) {
            if(board[0][0] == Cell.X) {
                winner = 1;
            }
            else if(board[0][0] == Cell.O) {
                winner = 2;
            }
        }
        else if(board[2][0] == board[1][1] && board[0][0] == board[0][2]) {
            if(board[2][0] == Cell.X) {
                winner = 1;
            }
            else if(board[2][0] == Cell.O) {
                winner = 2;
            }
        }
        for(int i = 0; i < 3; i++) {
            for(int j = 0; j < 3; j++) {
                if(board[i][j] == Cell.EMPTY) {
                    checkEmpty = true;
                }
            }
        }
        if(!checkEmpty) {
            winner = 3;
        }
        return winner;
    }
    public void clearBoard()
    {
        for(int i=0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                board[i][j] = Cell.EMPTY;
            }
        }
    }
}

/**
 * Read web server data and analyse hourly access patterns.
 * 
 * @author David J. Barnes and Michael Kölling.
 * @version    2016.02.29
 */
public class LogAnalyzer
{
    // Where to calculate the hourly access counts.
    private int[] hourCounts;
    // Use a LogfileReader to access the data.
    private LogfileReader reader;
    private int[] dailyCounts;
    private int[] weeklyCounts;
    private int[] accessOutcomeCounts;

    /**
     * Create an object to analyze hourly web accesses.
     */
    public LogAnalyzer(String name)
    { 
        // Create the array object to hold the hourly
        // access counts.
        hourCounts = new int[24];
        // Create the reader to obtain the data.
        reader = new LogfileReader(name);
        dailyCounts = new int[365];
        weeklyCounts = new int[7];
        accessOutcomeCounts = new int[3];
    }

    /**
     * Analyze the hourly access data from the log file.
     */
    public void analyzeHourlyData()
    {
        while(reader.hasNext()) {
            LogEntry entry = reader.next();
            int hour = entry.getHour();
            hourCounts[hour]++;
        }
    }

    /**
     * Print the hourly counts.
     * These should have been set with a prior
     * call to analyzeHourlyData.
     */
    public void printHourlyCounts()
    {
        System.out.println("Hr: Count");
        int hour = 0;
        while( hour < hourCounts.length) {
            System.out.println(hour + ": " + hourCounts[hour]);
            hour++;
        }
    }
    
    /**
     * Print the lines of data read by the LogfileReader
     */
    public void printData()
    {
        reader.printData();
    }
    public int numberOfAcceses()
    {
        int total = 0;
        for(int i = 0; i < hourCounts.length; i++) {
            total += i;
        }
        return total;
    }
    public int busiestHour()
    {
        int highest = 0;
        int busiest = 0;
        for(int i = 0; i < hourCounts.length; i++) {
            if(hourCounts[i] > highest) {
                busiest = i;
                highest = hourCounts[i];
            }
        }
        return busiest;
    }
    public int queitestHour()
    {
        int lowest = 200;
        int quiet = 0;
        for(int i = 0; i < hourCounts.length; i++) {
            if(hourCounts[i] < lowest) {
                quiet = i;
                lowest = hourCounts[i];
            }
        }
        return quiet;
    }
    public int twoHourBiggest()
    {
        int max = 0;
        int busiestPair = 0; 
        for(int i = 0; i < hourCounts.length; i++) {
            int pair = hourCounts[i] + hourCounts[i + 1];
            if(pair > max) {
                max = pair;
                busiestPair = i;
            }
        }
        return busiestPair;
    }
    public void analyzeDailyData()
    {
        while(reader.hasNext()) {
            LogEntry entry = reader.next(); 
            int day = entry.getDay();
            dailyCounts[day]++; 
        } 
    }
    public int[] analyzeWeeklyPatterns()
    {
        for(int i = 0; i < 52; i++){ 
            for(int j = 0; j < 7; j++) { 
                weeklyCounts[j] += dailyCounts[i * 7 + j];
            }
        }
        weeklyCounts[0] += dailyCounts[364];
        weeklyCounts[1] += dailyCounts[365];
        return weeklyCounts;
    }
    public int busiestDay() 
    {
        int maxCount = 0;
        int busiestDay = 0;
        for(int i = 0; i < weeklyCounts.length; i++) {
            if(weeklyCounts[i] > maxCount) {
                busiestDay = i;
                maxCount = weeklyCounts[i];
            }
        }
        return busiestDay;
    }
    public int quietestDay() 
    {
        int minCount = numberOfAcceses();
        int quietestDay = 0;
        for(int i = 0; i < weeklyCounts.length; i++) {
            if(hourCounts[i] < minCount) {
                quietestDay = i;
                minCount = weeklyCounts[i];
            }
        }
        return quietestDay;
    }
    public void analyzeAccessOutcomes()
    {
        reader.reset();
        while(reader.hasNext()) {
            LogEntry entry = reader.next();
            int accessOutcome = entry.getAccessoutcome();
            if(accessOutcome == 200){
                accessOutcomeCounts[0]++;
            } else if (accessOutcome == 403) {
                accessOutcomeCounts[1]++;
            } else {
                accessOutcomeCounts[2]++;
            }
        }
        System.out.println("There were " + accessOutcomeCounts[0] + " succesful access attempts, " + accessOutcomeCounts[1] + " attempts to opet a secure document, and " +  accessOutcomeCounts[2] + " attempts to open a file that does not exist.");
    }
}
